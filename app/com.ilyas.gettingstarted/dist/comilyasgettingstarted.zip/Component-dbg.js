sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.ilyas.gettingstarted.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);